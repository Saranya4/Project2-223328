﻿using System;
namespace AppointmentApp.Models
{
    public class PatientInfo
    {

        public string id { get; set; }


        public string firstName { get; set; }


        public string lastName { get; set; }


        public string emailId { get; set; }


        public string password { get; set; }
    }
}
