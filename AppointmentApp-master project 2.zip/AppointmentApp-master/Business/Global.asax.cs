﻿using System.Web;

namespace Business
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
