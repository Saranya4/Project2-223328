﻿using System.Web;

namespace DataAccess
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
