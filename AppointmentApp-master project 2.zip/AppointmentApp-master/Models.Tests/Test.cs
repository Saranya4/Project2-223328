﻿using NUnit.Framework;
using System;

namespace Models.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
