﻿using System.Web;

namespace Models
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
